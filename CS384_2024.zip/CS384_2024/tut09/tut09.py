import numpy as np
import pandas as pd
from datetime import datetime, time, date
from openpyxl import Workbook
from openpyxl.styles import PatternFill
import re

# Read Students
def read_students():
  with open('/content/stud_list.txt', 'r') as f:
   students = f.read().splitlines()
  return students

# Read Attendance
def read_attendance():
  attendance = pd.read_csv('/content/input_attendance.csv')
  return attendance

# Read Dates
def read_dates():
  with open('/content/python dates.txt', 'r') as file:
    content = file.read()

  taken_dates_pattern = r'classes_taken_dates = \[([^\]]+)\]'
  missed_dates_pattern = r'classes_missed_dates = \[([^\]]+)\]'
  exams_dates_pattern = r'exams_dates = \[([^\]]+)\]'

  taken_dates_str = re.search(taken_dates_pattern, content).group(1)
  missed_dates_str = re.search(missed_dates_pattern, content).group(1)
  exams_dates_str = re.search(exams_dates_pattern, content).group(1)

  taken_dates = [date.strip().strip('"') for date in taken_dates_str.split(',')]
  missed_dates = [date.strip().strip('"') for date in missed_dates_str.split(',')]
  exams_dates = [date.strip().strip('"') for date in exams_dates_str.split(',')]

  merged_dates = taken_dates + exams_dates + missed_dates
  merged_dates.sort(key=lambda date: datetime.strptime(date, "%d/%m/%Y"))
  merged_dates_as_date = [datetime.strptime(date_str, "%d/%m/%Y").date() for date_str in merged_dates]

  return merged_dates_as_date

# Checking Attendance
def check_attendance(students, attendance, dates):
  start_time = time(18, 0, 0)
  end_time = time(20, 0, 0)
  attendance_data = {student: {date: 0 for date in dates} for student in students}
  total_attendance = {student: {"Total":0} for student in students}
  proxy = {student: {"Proxy":0} for student in students}

  for _, row in attendance.iterrows():
    student, timestamp = row['Roll'], row['Timestamp']
    timestamp = datetime.strptime(timestamp, "%d/%m/%Y %H:%M:%S")

    #Checking Proxies
    if timestamp.date() not in [date for date in dates] and student in students:
      proxy[student]["Proxy"] += 1
    if student in students and timestamp.time() < start_time or timestamp.time() > end_time:
      proxy[student]["Proxy"] += 1

    # Counting Attendance
    for date_obj in dates:
      if timestamp.date() == date_obj and (start_time <= timestamp.time() <= end_time) and student in students:
        attendance_data[student][date_obj] += 1
        total_attendance[student]["Total"] += 1

  return attendance_data, total_attendance, proxy

# Generating Excel file
def generate_excel(attendance_data, total, dates, proxy, output_file):
  wb = Workbook()
  ws = wb.active
  ws.title = "Attendance Record"
  no_of_dates = len(dates)

  header = ["Roll Number"] + \
           [date.strftime("%Y/%m/%d") for date in next(iter(attendance_data.values())).keys()] + \
           ["Total Count Of Dates"] + \
           ["Total Attendance Marked"] + \
           ["Total Attendance Allowed"] + \
           ["Proxy"]
  ws.append(header)

  fill_absent = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
  fill_partial = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
  fill_full = PatternFill(start_color="00FF00", end_color="00FF00", fill_type="solid")

  for student, record in attendance_data.items():
    row = [student] + list(record.values()) + \
          [no_of_dates - 2] + [total[student]["Total"]] + \
          [2*(no_of_dates-2)] + \
          [proxy[student]["Proxy"]]
    if total[student]["Total"] == 0:
      continue
    ws.append(row)

  for row in ws.iter_rows(min_row=2, min_col=2, max_row=len(attendance_data) + 1, max_col=len(header)-4):
    for cell in row:
      if cell.value is not None and isinstance(cell.value, (int, float)):
       if cell.value >= 3:
         cell.fill = fill_absent
       elif cell.value == 1:
         cell.fill = fill_partial
       elif cell.value == 2:
         cell.fill = fill_full

  wb.save(output_file)

students = read_students()
attendance = read_attendance()
dates = read_dates()

attendance_final, total, proxy = check_attendance(students, attendance, dates)
generate_excel(attendance_final, total, dates, proxy, "/content/output_excel.xlsx")

# Download file in Colab
from google.colab import files
files.download("/content/output_excel.xlsx")